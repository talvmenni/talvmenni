package edu.emory.mathcs.util.security.auth;

public interface RemoteCredential {
    String[] getSupportedProtocols();
    Object getPublicCredential();
    AuthDialogClient initiateAuth(String protocol);
}
