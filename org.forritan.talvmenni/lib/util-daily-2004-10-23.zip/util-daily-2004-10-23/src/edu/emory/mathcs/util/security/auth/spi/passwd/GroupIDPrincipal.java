/*
 * UserPrincipal.java
 *
 * Created on January 13, 2003, 6:36 PM
 */
package edu.emory.mathcs.util.security.auth.spi.passwd;

import java.security.*;


/**
 * DOCUMENT ME!
 *
 * @author Drzewo
 */
public class GroupIDPrincipal extends IDPrincipal implements Principal {
    /** DOCUMENT ME! */
    private final String name;

    /**
     * Creates a new instance of GroupIDPrincipal
     *
     * @param name DOCUMENT ME!
     */
    public GroupIDPrincipal(String name) {
        this.name = name;
    }

    /**
     * Returns the name of this principal.
     *
     * @return the name of this principal.
     */
    public String getName() {
        return name;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString() {
        return ("GroupIDPrincipal: " + getName());
    }

    /**
     * Compares the specified Object with this <code>GroupIDPrincipal</code>.
     * Returns true if the specified object is an instance of
     * <code>GroupIDPrincipal</code> and has the same name as this
     * GroupIDPrincipal
     *
     * @param object Object to be compared
     *
     * @return true if the specified Object is equal to this
     *         <code>GroupIDPrincipal</code>.
     */
    public boolean equals(Object object) {
        if (!(object instanceof GroupIDPrincipal)) {
            return false;
        }

        if (object == this) {
            return true;
        }

        if (getName().equals(((GroupIDPrincipal) object).getName())) {
            return true;
        }

        return false;
    }
}
