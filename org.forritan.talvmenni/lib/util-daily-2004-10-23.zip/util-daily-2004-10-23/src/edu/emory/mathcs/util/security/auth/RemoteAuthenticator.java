package edu.emory.mathcs.util.security.auth;

import edu.emory.mathcs.util.security.auth.server.impl.*;

public interface RemoteAuthenticator {
    String[] getSupportedProtocols();
    AuthDialog initiateAuthentication(String protocol);
}
