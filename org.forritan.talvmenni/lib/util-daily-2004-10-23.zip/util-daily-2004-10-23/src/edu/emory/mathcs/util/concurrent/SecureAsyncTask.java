/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.concurrent;

import edu.emory.mathcs.util.concurrent.*;

/**
 * Variant of {@link AsyncTask} that overrides method
 * {@link edu.emory.mathcs.util.concurrent.AsyncTask#createPerformer
 *  createPerformer} so that
 * it always runs with a fixed access control context and
 * {@link ThreadContext thread context} inherited from the caller of
 * createPerformer method. This class is intended primarily for subclassing.
 * Typical usage scenario in subclasses is to create a new instance and
 * call <code>createPerformer</code>. As a result, one obtains a runnable that
 * will perform assigned task with the same access permissions,
 * {@link DelegatableThreadLocal}s, and the context class loader, regardless
 * of the thread that actually executes the runnable.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */
public class SecureAsyncTask extends AsyncTask {

    protected SecureAsyncTask() {
        super();
    }

    protected SecureAsyncTask(Callback cb) {
        super(cb);
    }

    /**
     * Creates a runnable that will execute specified call and then mark this
     * AsyncTask with the result of that call. The runnable will run
     * with access control context and {@link ThreadContext} inherited from
     * this method's invoker, regardless of the thread that will actually
     * execute it.
     * If the call completes successfully, this AsyncTask is marked
     * completed with the result returned by the call. If the call
     * throws an exception, the AsyncTask is marked as failed with
     * cause being that exception. The stack trace of the thread in which
     * the performer is created is appended to the failure cause stack
     * trace unless the disableStackTraces parameter is set to false.
     * <p>
     * This method is intended to be used by subclasses. Runnable
     * returned from this method should be executed only once -- subsequent
     * execution attempts will fail due to "task already completed" condition.
     *
     * @param call the call to execute
     * @param disableStackTraces if true, does not append invoker stack trace
     *        to traces of exceptions thrown during execution of the runnable
     * @return runnable that will execute specified call and
     *         set the result of this AsyncTask upon completion
     */
    protected Runnable createPerformer(Callable call, boolean disableStackTraces) {
        return new DelegatedRunnable(super.createPerformer(call, disableStackTraces));
    }

    /**
     * Schedules specified task with given executor, and returns
     * completion handle that can be used to access the result or to cancel
     * the task. The task will run
     * with access control context and {@link ThreadContext} inherited from
     * this method's invoker, regardless of the thread that will actually
     * execute it.
     * Later, if task completes successfully, the handle is marked
     * completed with the result that has been returned from the task.
     * If the task ends with an exception, the handle is marked
     * failed with cause being that exception. In such case, as a debugging
     * aid, current stack trace (that is, that of this method's invoker) is
     * appended to the original stack trace.
     *
     * @param executor the executor to use
     * @param call the task to schedule
     * @return completion handle that can be used to access the result or
     *         cancel the task
     */
    public static AsyncTask start(final Executor executor, final Callable call)
    {
        return start(executor, call, null);
    }

    /**
    * Schedules specified task with given executor, and returns
    * completion handle that can be used to access the result or to cancel
    * the task. The task will run
    * with access control context and {@link ThreadContext} inherited from
    * this method's invoker, regardless of the thread that will actually
    * execute it.
    * Later, if task completes successfully, the handle is marked
    * completed with the result that has been returned from the task.
    * If the task ends with an exception, the handle is marked
    * failed with cause being that exception. In such case, as a debugging
    * aid, current stack trace (that is, that of this method's invoker) is
    * appended to the original stack trace.
    *
    * @param executor the executor to use
    * @param call the task to schedule
    * @param cb callback to invoke upon completion
    * @return completion handle that can be used to access the result or
    *         cancel the task
    */
   public static AsyncTask start(final Executor executor, final Callable call,
                                  final Callback cb)
    {
        return start(executor, call, cb, false);
    }

    /**
     * Schedules specified task with given executor, and returns
     * completion handle that can be used to access the result or to cancel
     * the task. The task will run
     * with access control context and {@link ThreadContext} inherited from
     * this method's invoker, regardless of the thread that will actually
     * execute it.
     * Later, if task completes successfully, the handle is marked
     * completed with the result that has been returned from the task.
     * If the task ends with an exception, the handle is marked
     * failed with cause being that exception. In such case, as a debugging
     * aid, current stack trace (that is, that of this method's invoker) is
     * appended to the original stack trace unless
     * the disableStackTraces parameter is set to false
     *
     * @param executor the executor to use
     * @param call the task to schedule
     * @param cb callback to invoke upon completion
     * @param disableStackTraces if true, does not append invoker stack trace
     *        to traces of exceptions thrown during task execution
     * @return completion handle that can be used to access the result or
     *         cancel the task
     */
    public static AsyncTask start(final Executor executor, final Callable call,
                                  final Callback cb, boolean disableStackTraces)
    {
        final SecureAsyncTask task = new SecureAsyncTask(cb);
        executor.execute(task.createPerformer(call, disableStackTraces));
        return task;
    }

}
