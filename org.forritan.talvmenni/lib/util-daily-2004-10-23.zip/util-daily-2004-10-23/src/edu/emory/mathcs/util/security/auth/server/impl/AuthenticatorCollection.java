package edu.emory.mathcs.util.security.auth.server.impl;

import java.util.*;
import edu.emory.mathcs.util.security.auth.*;

/**
 * <p>Title: Util</p>
 * <p>Description: Emory MathCS Utility Classes</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Emory University</p>
 * @author not attributable
 * @version 1.0
 */

public class AuthenticatorCollection {
    final Set prots = new HashSet();
    final List authenticators = new ArrayList();

    public AuthenticatorCollection(List authenticators) {
        this.authenticators.addAll(authenticators);
        refreshProtocolMap();
    }

    public synchronized List getAuthenticatorList() {
        return Collections.unmodifiableList(authenticators);
    }

    public String[] getSupportedProtocols() {
        return (String[])prots.toArray(new String[prots.size()]);
    }

//    public RemoteAuthenticator getAuthenticator(String protocol) {
//        return (RemoteAuthenticator)prot2auth.get(protocol);
//    }
//
    private void refreshProtocolMap() {
        prots.clear();
        for (Iterator itr = authenticators.iterator(); itr.hasNext(); ) {
            RemoteAuthenticator auth = (RemoteAuthenticator)itr.next();
            String[] aprots = auth.getSupportedProtocols();
            for (int i=0; i<aprots.length; i++) {
                if (prots.contains(aprots[i])) continue;
                prots.add(aprots[i]);
            }
        }
    }
//

}