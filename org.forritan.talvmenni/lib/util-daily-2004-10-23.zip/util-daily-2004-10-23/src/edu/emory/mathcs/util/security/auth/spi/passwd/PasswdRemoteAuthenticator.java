package edu.emory.mathcs.util.security.auth.spi.passwd;

import edu.emory.mathcs.util.security.auth.AuthResult;
import edu.emory.mathcs.util.security.auth.RemoteCredential;
import edu.emory.mathcs.util.security.auth.RemoteAuthenticator;
import edu.emory.mathcs.util.security.auth.server.impl.*;
import java.io.*;
import edu.emory.mathcs.util.security.*;
import edu.emory.mathcs.util.security.auth.server.*;
import java.security.Principal;
import java.util.Collections;
import java.util.*;

public class PasswdRemoteAuthenticator implements RemoteAuthenticator {

    UserDatabase db;

    protected PasswdRemoteAuthenticator(UserDatabase db) {
        this.db = db;
    }

    public String[] getSupportedProtocols() {
        return PasswdRemoteCredential.staticGetSupportedProtocols();
    }

    public AuthDialog initiateAuthentication(String protocol) {
        checkProtocol(protocol);
        return new PasswdDialog();
    }

    private class PasswdDialog implements AuthDialog {
        String detailMessage;
        int status = AuthResponse.IN_PROGRESS;
        Set principals = new HashSet();
        PasswdPublicCredential publicCred;
        PasswdRemoteCredential delegated;

        public void doPhase(byte[] token) {
            if (status != AuthResponse.IN_PROGRESS) {
                throw new IllegalStateException();
            }
            ByteArrayInputStream bis = new ByteArrayInputStream(token);
            DataInputStream dis = new DataInputStream(bis);
            String username;
            char[] passwd = null;
            boolean delegate;
            try {
                PasswdPublicCredential publicCred = PasswdPublicCredential.readFrom(dis);
                passwd = CharStrings.readUTF((DataInput)dis);
                delegate = dis.readBoolean();
                UserDatabase.User user = db.getUser(publicCred.getUserID());
                if (user == null) {
                    status = AuthResponse.FAILED;
                    detailMessage = "Unknown user \"" + publicCred.getUserID() + "\"";
                    return;
                }
                boolean passwdok = user.verifyPassword(passwd);
                if (passwdok) {
                    status = AuthResponse.SUCCEEDED;
                    this.publicCred = publicCred;
                    detailMessage = "Authenticated";
                    principals.add(new UserIDPrincipal(publicCred.getUserID()));
                    String[] groupNames = user.getGroups();
                    if (groupNames != null) {
                        for (int i=0; i<groupNames.length; i++) {
                            principals.add(new GroupIDPrincipal(groupNames[i]));
                        }
                    }
                    if (delegate) {
                        this.delegated = new PasswdRemoteCredential(publicCred, passwd, true);
                    }
                }
                else {
                    status = AuthResponse.FAILED;
                    detailMessage = "Incorrect password";
                }
            }
            catch (IOException e) {
                status = AuthResponse.FAILED;
                detailMessage = "Protocol error";
            }
            finally {
                CharStrings.clear(passwd);
            }
        }

        public byte[] getNextToken() {
            // auth with password is one-phase only
            throw new IllegalStateException("This is one-phase protocol");
        }

        public String getDetailMessage() {
            return detailMessage;
        }

        public int getStatus() {
            return status;
        }

        public Set getAuthenticatedPrincipals() {
            return principals;
        }

        public Set getPublicCredentials() {
            return publicCred == null ? Collections.EMPTY_SET
                                      : Collections.singleton(publicCred);
        }

        public Set getDelegatedCredentials() {
            return delegated == null ? Collections.EMPTY_SET
                                     : Collections.singleton(delegated);
        }
    }

    private void checkProtocol(String protocol) {
        if (!(PasswdRemoteCredential.PROTOCOL.equalsIgnoreCase(protocol))) {
            throw new IllegalArgumentException("Unsupported protocol: " + protocol);
        }
    }
}
