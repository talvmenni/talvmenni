/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.xml;

import org.xml.sax.*;
import java.net.*;
import java.util.*;
import java.io.*;

/**
 * SAX entity resolver that associates public IDs to URLs of their appropriate
 * DTD specifications. For example, DTD may be stored in a JAR file (as a
 * resource); then, the URL of the DTD will be the JAR URL pointing to that
 * resource. When the SAX parser encounters XML document with this public ID,
 * it will be able to resolve and load the DTD, and then validate the document.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */

public class DTDResolver implements EntityResolver {

    final Map pubid2url = new HashMap();

    /**
     * Creates a new DTD resolver with no ID to URL associations.
     */
    public DTDResolver() {
    }

    /**
     * Creates a new DTD resolver with the specified ID to URL association.
     *
     * @param pubID the public ID
     * @param dtdUrl the URL of the DTD associated with that public ID
     */
    public DTDResolver(String pubID, URL dtdUrl) {
        addMapping(pubID, dtdUrl);
    }

    /**
     * Adds a specified ID to URL association to the mapping.
     *
     * @param pubID the public ID
     * @param dtdUrl the URL of the DTD associated with that public ID
     */
    public void addMapping(String pubID, URL dtdUrl) {
        if (dtdUrl == null) throw new NullPointerException();
        pubid2url.put(pubID, dtdUrl);
    }

    public InputSource resolveEntity(String pubID, String sysID) throws SAXException {
        URL dtdUrl = (URL)pubid2url.get(pubID);
        if (dtdUrl == null) {
            throw new SAXException("The document public ID is: \"" + pubID +
                "\" while it should be (one of): { " + enumerateMappedIDs() + " }");
        }
        try {
            return new InputSource(dtdUrl.openConnection().getInputStream());
        }
        catch (IOException e) {
            throw new SAXException("Unable to read DTD definition from " + dtdUrl, e);
        }
    }

    private String enumerateMappedIDs() {
        boolean first = true;
        StringBuffer buf = new StringBuffer();
        for (Iterator i = pubid2url.keySet().iterator(); i.hasNext(); ) {
            if (first) {
                first = false;
            } else {
                buf.append(", ");
            }
            buf.append('"').append(i.next()).append('"');
        }
        return buf.toString();
    }
}