package edu.emory.mathcs.util;

import java.util.*;
import java.io.*;

/**
 * Set of long numbers that is optimized towards clustered distributions.
 * The implementation keeps the atomic information about ranges of numbers,
 * hence this set can hold billions of elements as long as
 * they form clusters (long consecutive runs). The main application of this
 * class is in collision detection arrays, e.g. to aid in generation unique IDs
 * that are roughly sequential but possibly cyclic (process IDs, packet IDs)
 * with ID recycling and gap filling.
 * <p>
 * This class is stable but a bit of "work in progress": it does not support
 * removal of elements, or seeking for empty slots.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */

public class RangeBasedSetOfLongs {

    private static class Range {
        private long start;
        private long end;
        Range(long start, long end) {
            //assert (start >= end);
            this.start = start;
            this.end = end;
        }
        void setStart(long newStart) {
            //assert (newStart <= end);
            this.start = newStart;
        }
        void setEnd(long newEnd) {
            //assert (start <= newEnd);
            this.end = newEnd;
        }
        boolean contains(long l) {
            return (start <= l && l <= end);
        }
        public String toString() {
            return  "[" + (start==end ? "" + start : "" + end + ".." + start) + "]";
        }
    }

    private static Comparator comparator = new Comparator() {
        public int compare(Object o1, Object o2) {
            if (o1 instanceof Long && o2 instanceof Long) {
                long l1 = ((Long)o1).longValue();
                long l2 = ((Long)o2).longValue();
                return l1 < l2 ? -1 : l1 > l2 ? 1 : 0;
            }
            else if (o1 instanceof Long) {
                return -compare((Range)o2, ((Long)o1).longValue());
            }
            else if (o2 instanceof Long) {
                return compare((Range)o1, ((Long)o2).longValue());
            }
            // both are ranges; this is to reorganize the tree after addition
            // or removal, not to find the insertion point
            Range r1 = (Range)o1;
            Range r2 = (Range)o2;
            if (r1.end < r2.start) return 1;
            if (r1.start > r2.end) return -1;
            throw new RuntimeException("Total ordering is broken");
        }
        // find the insertion point for a given long. Insertion point is a
        // leftmost range that the given long may be appended to from the
        // right side
        private int compare(Range r, long l) {
            if (r.start-1 > l) return -1;
            if (l > r.end) return 1;
            return 0;
        }
    };

    SortedSet baseSet = new TreeSet(comparator);

    /**
     * Creates a new set of longs.
     */
    public RangeBasedSetOfLongs() {
    }

    /**
     * Removes all elements from the set.
     */
    public void clear() {
        baseSet.clear();
    }

//    /**
//     * Find the first range that is either adjacent to the l, contains it,
//     * or have all values less than it. If "l" is bigger than any number
//     * in the set, the whole set will be returned.
//     */
    private SortedSet getInsertionPoint(long l) {
        Long lobj = new Long(l);
        return baseSet.tailSet(lobj);
    }

    /**
     * Adds an element to the set if it is not already present.
     * @param l the element to add
     *
     * @return true is the element was added; false if it was already present
     */
    public boolean add(long l) {
        SortedSet tail = getInsertionPoint(l);
        Iterator i = tail.iterator();
        // "" denotes the tail set found, * denotes l, [...] is a range
        if (!(i.hasNext())) {
            // [987]..l=4.. -> [987]..[4]
            baseSet.add(new Range(l, l));
            return true;
        }
        Range r1 = (Range)i.next();
        if (r1.contains(l)) return false;
        if (l > r1.end+1) {
            // [987]..l=4."21" -> [987]..[4].[21]
            baseSet.add(new Range(l, l));
            return true;
        }
        if (l == r1.end+1) {
            // [987]...l=3"[21]" -> // [987]...[321]
            r1.end++;
            return true;
        }
        else if (l == r1.start-1) {
            // 1. [987]l=6.[43] -> [9876].[43]
            // 2. [987]l=6[543] -> [9876543]
            if (i.hasNext()) { // possible case 2.
                Range r2 = (Range)i.next();
                if (l == r2.end+1) { // case 2. indeed
                    i.remove();
                    r1.start = r2.start;
                    return true;
                }
            }
            // case 1.
            r1.start--;
            return true;
        }
        throw new RuntimeException();
    }

    /**
     * Checks whether the set contains a given element
     *
     * @param l the element
     * @return true if the set contains l, false otherwise
     */
    public boolean contains(long l) {
        // we use the fact that there must be always at least one number
        // between any two ranges, so the item adjacent to the range may
        // not be contained in any other range
        SortedSet tail = getInsertionPoint(l);
        Range r = (Range)tail.first();
        return (r.contains(l));
    }

    public String toString() {
        return baseSet.toString();
    }
}
