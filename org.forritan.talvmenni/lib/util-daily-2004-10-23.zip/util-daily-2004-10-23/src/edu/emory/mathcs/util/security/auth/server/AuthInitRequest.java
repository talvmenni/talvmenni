package edu.emory.mathcs.util.security.auth.server;

public class AuthInitRequest implements java.io.Serializable {
    public String protocol;
    public byte[] token;
    public AuthInitRequest() {}
    public AuthInitRequest(String protocol, byte[] token) {
        this.protocol = protocol;
        this.token = token;
    }
}
