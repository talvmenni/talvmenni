/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.allocator;

import java.lang.ref.*;
import java.util.*;

import edu.emory.mathcs.util.concurrent.*;
import edu.emory.mathcs.util.*;

/**
 * Memory pool used by {@link PoolingAllocator}.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */

class BufferPool {
    private final Queue[] pool;

    public BufferPool() {
        pool = new Queue[27];
        for (int i=0; i<pool.length; i++) {
            /** @todo try various queue implementations */
            pool[i] = new LinkedQueue();
        }
    }

    public byte[] get(int desiredsize, boolean clear) {
        int idx = getSlot(desiredsize);

        byte[] data;

        // try to find buf in the queue (optimistic - no locking)
        if ((data = getFromQueue(pool[idx])) != null) {
            if (clear) Arrays.fill(data, 0, desiredsize, (byte)0);
            return data;
        }

        if (idx<26) {
            // try also the next queue (with buffers 2x size)
            if ((data = getFromQueue(pool[idx+1])) != null) {
                if (clear) Arrays.fill(data, 0, desiredsize, (byte)0);
                return data;
            }
        }

        // not found, allocate new
        return new byte[16 << idx];
    }

    private byte[] getFromQueue(Queue q) {
        byte[] data;
        Reference ref;
        while (true) {
            // get subsequent buffers until end or not-null found
            // (references are weak so buffers can possibly be null)
            ref = (Reference)q.poll();
            if (ref == null) {
                // no more items in this queue
                return null;
            }
            data = (byte[])ref.get();
            if (data != null) {
                // found!
                return data;
            }
        }
    }

    public void reclaim(byte[] data) {
        int idx = getSlot(data.length);
        pool[idx].offer(new WeakReference(data));
    }

    private static int getSlot(int num) {
        if (num < 0) throw new IllegalArgumentException();
        if (num <= 16) return 0;
        return (log(num-1)+1)-4;
    }
//
//    private static int getSizeForSlot(int num) {
//        return 16 << num;
//    }

    public static int log(int n) {
        int result = 0;
        if (n < 0) throw new IllegalArgumentException();
        for (; n > 0; n >>= 1) result++;
        return result;
    }

    public static int nextPowerOfTwo(int n) {
        return 1 << (log(n-1)+1);
    }
}