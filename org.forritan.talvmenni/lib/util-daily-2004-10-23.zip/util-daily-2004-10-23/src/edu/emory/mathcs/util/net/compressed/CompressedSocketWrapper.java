/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.net.compressed;

import java.io.*;
import java.net.*;

import edu.emory.mathcs.util.io.*;
import edu.emory.mathcs.util.net.*;

/**
 * Socket wrappper that enables data compression over an established socket
 * connection. The output stream associated with this socket guarantees
 * that flush sends out all the data that has been written so far. Hence,
 * this kind of socket can be used as a transport for request-response-based
 * protocols, like RMI or RPC.
 *
 * @see edu.emory.mathcs.util.io.CompressedOutputStream
 *
 * @author Dawid Kurzyniec
 */
public class CompressedSocketWrapper extends SocketWrapper
    implements DecoratingSocket
{
    /**
     * Buffer size used for compression/decompression.
     */
    protected final int bufSize;

    /**
     * Creates new compression wrapper over an existing, bound socket.
     * @param delegate the socket to enable compression for
     * @throws SocketException if a socket exception occurs
     */
    public CompressedSocketWrapper(Socket delegate) throws SocketException {
        this(delegate, -1);
    }

    /**
     * Creates new compression wrapper over an existing, bound socket, using
     * specified buffer size for compression/decompression.
     *
     * @param delegate the socket to enable compression for
     * @param bufSize buffer size used for compression/decompression
     * @throws SocketException if a socket exception occurs
     */
    public CompressedSocketWrapper(Socket delegate, int bufSize) throws SocketException {
        super(delegate);
        this.bufSize = bufSize;
    }

    public Socket getBaseSocket() {
        return delegate;
    }

    public InputStream getInputStream() throws IOException {
        InputStream is = super.getInputStream();
        if (bufSize > 0) {
            return new CompressedInputStream(is, bufSize);
        }
        else {
            return new CompressedInputStream(is);
        }
    }

    public OutputStream getOutputStream() throws IOException {
        OutputStream out = super.getOutputStream();
        if (bufSize > 0) {
            return new CompressedOutputStream(out, bufSize);
        }
        else {
            return new CompressedOutputStream(out);
        }
    }
}
