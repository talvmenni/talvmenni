package edu.emory.mathcs.util.security.auth.spi.passwd;

import java.io.*;

/**
 * <p>Title: Util</p>
 * <p>Description: Emory MathCS Utility Classes</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Emory University</p>
 * @author not attributable
 * @version 1.0
 */

public class PasswdPublicCredential {
    private final String uid;
    public PasswdPublicCredential(String uid) {
        this.uid = uid;
    }
    public String getUserID() {
        return uid;
    }
    public void writeTo(DataOutputStream dos) throws IOException {
        dos.writeUTF(uid);
    }
    public static PasswdPublicCredential readFrom(DataInputStream dis)
        throws IOException
    {
        return new PasswdPublicCredential(dis.readUTF());
    }

    public String toString() {
        return uid;
    }
}