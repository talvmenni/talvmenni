package edu.emory.mathcs.util.security.auth;

import edu.emory.mathcs.util.security.auth.server.*;
import java.util.*;
import java.rmi.*;
import edu.emory.mathcs.util.*;

public class AuthContext {

    AuthContextSrv server;
    String[] serverProtocols;

    public AuthContext(AuthContextInfo srvInfo) {
        this.server = srvInfo.server;
        String[] serverProtocols = (String[])srvInfo.supportedProtocols.clone();
        Arrays.sort(serverProtocols);
        this.serverProtocols = serverProtocols;
    }

    public AuthResult authenticate(Wallet wallet) throws RemoteException {
        List pendingCreds = (wallet != null)
            ? new ArrayList(wallet.getCredentials())
            : Collections.EMPTY_LIST;
        Map cred2protocol = new IdentityHashMap();
        AuthResult result = new AuthResult();

        Iterator itr;
        int i;

        for (itr = pendingCreds.iterator(); itr.hasNext(); ) {
            RemoteCredential cred = (RemoteCredential)itr.next();
            String[] protocols = cred.getSupportedProtocols();
            int found = -1;
            for (i = 0; i < protocols.length; i++) {
                found = Arrays.binarySearch(serverProtocols, protocols[i]);
                if (found >= 0) break;
            }
            if (found < 0) {
                // cannot authenticate this credential due to the lack of
                // support by the server
                pendingCreds.remove(cred);
                result.addResult(cred.getPublicCredential(), false,
                                 "Credential type unsupported by the server");
            }
            else {
                cred2protocol.put(cred, serverProtocols[found]);
            }
        }

        if (pendingCreds.size() == 0) {
            // no server-recognized credentials at all, but server still
            // may accept guest logins, so we continue to finalizeAuth

        }
        else {
            authenticate0(pendingCreds, cred2protocol, result);
        }

        return result;
    }


    private void authenticate0(List creds, Map cred2protocol, AuthResult result)
        throws RemoteException
    {
        Map cred2dialog = new IdentityHashMap();
        RemoteCredential[] credsToProcess;
        int size = creds.size();
        credsToProcess = (RemoteCredential[])creds.toArray(
            new RemoteCredential[size]);
        AuthInitRequest[] initRequests = new AuthInitRequest[size];

        for (int i=0; i<credsToProcess.length; i++) {
            RemoteCredential cred = credsToProcess[i];
            String protocol = (String)cred2protocol.get(cred);
            AuthDialogClient dialog = cred.initiateAuth(protocol);
            cred2dialog.put(cred, dialog);
            byte[] initToken = dialog.getNextToken();
            initRequests[i] = new AuthInitRequest(protocol, initToken);
        }

        AuthResponse[] responses = server.initAuth(initRequests);

        while (true) {
            Map credsToProcessNextTurn = new IdentityHashMap();

            // process the answers from the server and produce a new set
            // of tokens for possibly smaller set of credentials
            // (authentication may have finished for some of them)
            for (int i=0; i<responses.length; i++) {
                AuthResponse response = responses[i];
                RemoteCredential cred = credsToProcess[i];
                switch (response.status) {
                    case AuthResponse.SUCCEEDED:
                        result.addResult(cred.getPublicCredential(), true,
                                         response.detailMessage);
                        break;
                    case AuthResponse.FAILED:
                        result.addResult(cred.getPublicCredential(), false,
                                         response.detailMessage);
                        break;
                    case AuthResponse.IN_PROGRESS:
                        AuthDialogClient dialog = (AuthDialogClient)cred2dialog.get(cred);
                        dialog.doPhase(response.token);
                        byte[] token = dialog.getNextToken();
                        AuthRequest request = new AuthRequest(response.dialogID, token);
                        credsToProcessNextTurn.put(cred, request);
                }
            }

            if (credsToProcessNextTurn.isEmpty()) return;

            // prepare the next turn request
            credsToProcess = (RemoteCredential[])
                credsToProcessNextTurn.keySet().toArray(
                    new RemoteCredential[credsToProcessNextTurn.size()]);
            AuthRequest[] requests = new AuthRequest[credsToProcess.length];
            for (int i=0; i<credsToProcess.length; i++) {
                requests[i] = (AuthRequest)credsToProcessNextTurn.get(credsToProcess[i]);
            }

            // perform the next turn
            responses = server.auth(requests);
        }
    }
}
