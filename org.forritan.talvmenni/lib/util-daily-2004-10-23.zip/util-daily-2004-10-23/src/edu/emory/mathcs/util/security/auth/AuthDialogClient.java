package edu.emory.mathcs.util.security.auth;

public interface AuthDialogClient {
    void doPhase(byte[] token);
    byte[] getNextToken();
}
