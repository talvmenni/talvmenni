/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.io;

import java.io.*;
import java.util.*;
import edu.emory.mathcs.util.concurrent.*;

/**
 * Input source that supports read with timeouts. If timeout occurs before
 * any data is available, TimeoutException is thrown.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */
public interface TimedInput extends Input {

    /**
     * Read a byte of data if available within specified timeout.
     *
     * @param timeout the number of milliseconds to wait for data
     * @return the byte of data read
     * @throws IOException if an I/O error occurs
     * @throws TimeoutException if timeout occurs before data is available
     *
     * @see InputStream#read()
     */
    int timedRead(long timeout) throws IOException, TimeoutException;

    /**
     * Reads some number of bytes of data from the input stream into
     * an array of bytes.  An attempt is made to read as many as
     * <code>buf.length</code> bytes, but a smaller number may be read.
     * The number of bytes actually read is returned as an integer.
     * If <code>buf</code> has nonzero size but no data is available within the
     * specified timeout and the stream is not at EOF, TimeoutException is
     * thrown.
     *
     * @param buf the buffer into which the data is read
     * @param timeout the maximum number of milliseconds to wait before data
     *                is available
     * @return the actual number of bytes read
     * @throws IOException if an I/O error occurs
     * @throws TimeoutException if timeout occurs before data is available
     *
     * @see InputStream#read(byte[])
     */
    int timedRead(byte[] buf, long timeout) throws IOException, TimeoutException;

    /**
     * Reads up to <code>len</code> bytes of data from the input stream into
     * an array of bytes.  An attempt is made to read as many as
     * <code>len</code> bytes, but a smaller number may be read.
     * The number of bytes actually read is returned as an integer.
     * If nonzero bytes is requested but no data is available within the
     * specified timeout and the stream is not at EOF, TimeoutException is
     * thrown.
     *
     * @param buf the buffer into which the data is read
     * @param off the start offset in array <code>buf</code> where data
     *            is written
     * @param len the maximum number of bytes to read
     * @param timeout the maximum number of milliseconds to wait before data
     *                is available
     * @return the actual number of bytes read
     * @throws IOException if an I/O error occurs
     * @throws TimeoutException if timeout occurs before data is available
     *
     * @see InputStream#read(byte[],int,int)
     */
    int timedRead(byte[] buf, int off, int len, long timeout) throws IOException,
                                                                     TimeoutException;
}
