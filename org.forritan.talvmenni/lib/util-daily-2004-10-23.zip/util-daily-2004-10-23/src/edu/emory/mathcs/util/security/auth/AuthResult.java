package edu.emory.mathcs.util.security.auth;

import java.util.*;

public class AuthResult {

    Map results = new HashMap();

    AuthResult() {}

    void addResult(Object publicCred, boolean success, String detailMessage) {
        results.put(publicCred, new Entry(success, detailMessage));
    }

    public Map getResultsForCredentials() {
        return Collections.unmodifiableMap(results);
    }

    public Map getResultForCredentials(boolean accepted, boolean rejected) {
        Map processed = new HashMap();
        for (Iterator i=results.entrySet().iterator(); i.hasNext();) {
            Map.Entry mentry = (Map.Entry)i.next();
            Entry authEntry = (Entry)mentry.getValue();
            if (accepted && authEntry.isSuccessful()) {
                processed.put(mentry.getKey(), authEntry);
            }
            if (rejected && !authEntry.isSuccessful()) {
                processed.put(mentry.getKey(), authEntry);
            }
        }
        return processed;
    }

    public class Entry {

        final boolean success;
        final String detailMessage;

        Entry(boolean success, String detailMessage) {
            this.success = success;
            this.detailMessage = detailMessage;
        }

        public boolean isSuccessful() {
            return success;
        }

        public String getDetailMessage() {
            return detailMessage;
        }

        public String toString() {
            return "Authentication " + (success ? "successful" : "failed") +
                (detailMessage != null && detailMessage.trim().length() > 0 ?
                 ": " + detailMessage : "");
        }
    }

    public String toString() {
        return results.toString();
    }
}
