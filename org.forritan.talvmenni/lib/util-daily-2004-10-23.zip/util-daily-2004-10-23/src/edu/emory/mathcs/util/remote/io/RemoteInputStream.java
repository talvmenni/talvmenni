/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.remote.io;

import java.io.*;
import edu.emory.mathcs.util.remote.io.server.*;
import edu.emory.mathcs.util.remote.io.server.impl.*;

/**
 * Serializable input stream that reads from an input stream on a remote host,
 * using RMI. Since RMI itself can be enabled over various protocols and
 * socket factories, this class allows to tunnel byte streams through a variety
 * of protocols. For example, if used with RMIX, it is possible to tunnel
 * streams via SOAP/HTTP. Typical usage pattern is to create the instance
 * at the server side and then send it to the client via RMI. For example:
 *
 * <pre>
 * InputStream getRemoteStream() throws RemoteException {
 *    InputStream source = ...;
 *    return new RemoteInputStream(source);
 * }
 * </pre>
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */

public class RemoteInputStream extends InputStream implements Externalizable {
    RemoteInputStreamSrv server;

    /** for deserialization only */
    public RemoteInputStream() {}

    /**
     * Constructs a new serializable remote input stream reading from the
     * specified stream.
     *
     * @param in the source stream
     */
    public RemoteInputStream(InputStream in) {
        this(new RemoteInputStreamSrvImpl(in));
    }

    /**
     * Constructs a new serializable remote input stream reading from the
     * specified stream handle. Use this constructor on the client side if
     * the RMI handle to the server has been already created.
     *
     * @param server RMI handle to the source stream
     */
    public RemoteInputStream(RemoteInputStreamSrv server) {
        if (server == null) {
            throw new NullPointerException("server");
        }
        this.server = server;
    }

    public int read() throws IOException {
        byte[] buf = server.read(1);
        if (buf == null) { // EOF
            return -1;
        }
        return buf[0];
    }

    public int read(byte[] b, int off, int len) throws IOException {
        byte[] buf = server.read(len);
        if (buf == null) { // EOF
            return -1;
        }
        System.arraycopy(buf, 0, b, off, buf.length);
        return buf.length;
    }

    public long skip(long n) throws IOException {
        return server.skip(n);
    }

    public int available() throws IOException {
        return server.available();
    }

    public void close() throws IOException {
        server.close();
    }

    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(server);
    }

    public void readExternal(ObjectInput in) throws IOException,
        ClassNotFoundException
    {
        server = (RemoteInputStreamSrv)in.readObject();
    }
}
