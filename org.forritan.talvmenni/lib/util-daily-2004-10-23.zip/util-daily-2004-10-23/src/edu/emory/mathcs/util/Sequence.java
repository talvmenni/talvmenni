/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util;

/**
 * Objects of this class produce sequence of integer numbers. Both the initial
 * and max index, as well as the increment, can be specified. This
 * implementation does not allow to reclaim indexes.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */
public class Sequence {
    int idx, initidx, maxidx, increment;
    boolean wrapAround = false;

    /**
     * Creates a new sequence with initial index of 0, maximum index of
     * <code>Integer.MAX_VALUE</code>, and increment of 1.
     */
    public Sequence() {
        this(0);
    }

    /**
     * Creates a new sequence with specified initial index, maximum index of
     * <code>Integer.MAX_VALUE</code>, and increment of 1.
     *
     * @param initidx initial index.
     */
    public Sequence(int initidx) {
        this(initidx, Integer.MAX_VALUE);
    }

    /**
     * Creates a new sequence with specified initial and maximum index,
     * and increment of 1.
     *
     * @param initidx initial index.
     * @param maxidx maximum index.
     */
    public Sequence(int initidx, int maxidx) {
        this(initidx, maxidx, 1);
    }

    /**
     * Creates a new sequence with specified initial index, maximum index,
     * and increment.
     *
     * @param initidx initial index.
     * @param maxidx maximum index.
     * @param increment the increment.
     */
    public Sequence(int initidx, int maxidx, int increment) {
        this.idx = initidx;
        this.initidx = initidx;
        this.maxidx = maxidx;
        this.increment = increment;
    }

    /**
     * Sets the wrap-around flag for that sequence. If the flag is
     * <code>true</code>, the sequence is allowed to start over if it reached
     * the max index. Otherwise, it would throw
     * <code>IllegalStateException</code>. By default, this flag is set to
     * <code>false</code>.
     */
    public synchronized void setWrapAround(boolean wrapAround) {
        this.wrapAround = wrapAround;
    }

    /**
     * Returns the next index from this sequence.
     *
     * @see Sequence#setWrapAround(boolean)
     * @throws IllegalStateException if the max index has been already
     * reached and the wrap-around property is set to <code>false</code>.
     */
    public synchronized int next() {
        if (idx >= maxidx) {
            if (wrapAround) {
                idx = initidx;
            } else {
                throw new IllegalStateException("sequence overflow");
            }
        }
        int ret = idx;
        idx += increment;
        return ret;
    }

    /**
     * Resets this sequence to its initial state.
     */
    public synchronized void reset() {
        this.idx = initidx;
    }
}