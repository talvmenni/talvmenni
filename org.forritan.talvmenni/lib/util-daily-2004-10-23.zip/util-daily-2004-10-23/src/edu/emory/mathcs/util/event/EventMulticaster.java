/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.event;

import edu.emory.mathcs.util.concurrent.UncaughtExceptionHandler;

/**
 * Abstraction of thread-safe event dispatcher that supports registering
 * listeners while events are dispatched.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */
public class EventMulticaster {
    private Listener listener;
    final UncaughtExceptionHandler exhandler;

    public EventMulticaster() {
        this(null);
    }

    public EventMulticaster(UncaughtExceptionHandler exhandler) {
        this.exhandler = exhandler;
    }

    protected synchronized void addListener(Listener l) {
        this.listener = EventMulticaster.this.add(this.listener, l);
    }

    /**
     * @return true if multicaster gets empty as the result of this
     *         operation, false otherwise
     */
    protected synchronized boolean removeListener(Listener l) {
        this.listener = EventMulticaster.this.remove(this.listener, l);
        return isEmpty();
    }

    public synchronized boolean isEmpty() {
        return (this.listener == null);
    }

    protected void fire(Object e) {
        Listener l;
        synchronized (this) {
            l = this.listener;
        }
        if (l != null) l.handleEvent(e);
    }

    public static interface Listener {
        void handleEvent(Object evt);
    }

    protected class Node implements Listener {

        protected final Listener a, b;

        /**
         * Creates an event multicaster instance which chains listener-a
         * with listener-b. Input parameters <code>a</code> and <code>b</code>
         * should not be <code>null</code>, though implementations may vary in
         * choosing whether or not to throw <code>NullPointerException</code>
         * in that case.
         * @param a listener-a
         * @param b listener-b
         */
        protected Node(Listener a, Listener b) {
            this.a = a; this.b = b;
        }

        /**
         * Removes a listener from this multicaster and returns the
         * resulting multicast listener.
         * @param oldl the listener to be removed
         */
        protected Listener remove(Listener oldl) {
            if (oldl.equals(a))  return b;
            if (oldl.equals(b))  return a;
            Listener a2 = EventMulticaster.this.remove(a, oldl);
            Listener b2 = EventMulticaster.this.remove(b, oldl);
            if (a2 == a && b2 == b) {
                return this;	// it's not here
            }
            return add(a2, b2);
        }

        /**
         * Handles the event by invoking the
         * handleEvent methods on listener-a and listener-b.
         * @param e the event
         */
        public void handleEvent(Object evt) {
            handleEvent(evt, a);
            handleEvent(evt, b);
        }

        private void handleEvent(Object evt, Listener listener) {
            try {
                listener.handleEvent(evt);
            }
            catch (Exception e) {
                if (exhandler != null) {
                    exhandler.uncaughtException(Thread.currentThread(), e);
                }
            }
        }
    }

    /**
     * Returns the resulting multicast listener from adding listener-a
     * and listener-b together.
     * If listener-a is null, it returns listener-b;
     * If listener-b is null, it returns listener-a
     * If neither are null, then it creates and returns
     * a new EventMulticaster instance which chains a with b.
     * @param a event listener-a
     * @param b event listener-b
     */
    protected Listener add(Listener a, Listener b) {
        if (a == null)  return b;
        if (b == null)  return a;
        return new Node(a, b);
    }

    /**
     * Returns the resulting multicast listener after removing the
     * old listener from listener-l.
     * If listener-l equals the old listener OR listener-l is null,
     * returns null.
     * Else if listener-l is an instance of EventMulticaster,
     * then it removes the old listener from it.
     * Else, returns listener l.
     * @param l the listener being removed from
     * @param oldl the listener being removed
     */
    protected Listener remove(Listener l, Listener oldl) {
        if (oldl.equals(l) || l == null) {
            return null;
        } else if (l instanceof Node) {
            return ((Node)l).remove(oldl);
        } else {
            return l;		// it's not here
        }
    }
}


