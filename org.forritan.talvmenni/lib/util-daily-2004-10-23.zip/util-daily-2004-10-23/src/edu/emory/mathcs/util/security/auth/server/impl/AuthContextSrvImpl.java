package edu.emory.mathcs.util.security.auth.server.impl;

import edu.emory.mathcs.util.security.auth.server.AuthResponse;
import edu.emory.mathcs.util.security.auth.server.AuthInitRequest;
import java.rmi.RemoteException;
import edu.emory.mathcs.util.security.auth.server.AuthRequest;
import edu.emory.mathcs.util.security.auth.server.AuthContextSrv;
import java.util.*;
import edu.emory.mathcs.util.security.auth.*;
import edu.emory.mathcs.util.*;
import java.lang.ref.*;
import java.security.*;

/**
 * <p>Title: H2O</p>
 * <p>Description: H2O Distributed Computing Platform</p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Emory University</p>
 * @author not attributable
 * @version 1.0
 */

public class AuthContextSrvImpl implements AuthContextSrv {
    protected final AuthenticatorCollection authenticators;
    final List dialogs = new ArrayList();

    public AuthContextSrvImpl(AuthenticatorCollection authenticators)
    {
        this.authenticators = authenticators;
    }
    public String[] getSupportedProtocols() {
        return authenticators.getSupportedProtocols();
    }
    public AuthResponse[] initAuth(AuthInitRequest[] requests) throws RemoteException {
        AuthResponse[] responses = new AuthResponse[requests.length];
        for (int i=0; i<requests.length; i++) {
            AuthInitRequest request = requests[i];
            List auths = authenticators.getAuthenticatorList();
            AuthDialog dialog = null;
            for (Iterator itr = auths.iterator(); itr.hasNext();) {
                RemoteAuthenticator auth = (RemoteAuthenticator)itr.next();
                if (!Arrays.asList(auth.getSupportedProtocols()).contains(request.protocol)) {
                    continue;
                }
                dialog = auth.initiateAuthentication(request.protocol);
                dialog.doPhase(request.token);
                int status = dialog.getStatus();
                if (status != AuthResponse.FAILED) {
                    break;
                }
            }

            if (dialog == null) {
                throw new RemoteException("Unsupported auth protocol: " + request.protocol);
            }

            byte[] token;
            if (dialog.getStatus() == AuthResponse.IN_PROGRESS) {
                token = dialog.getNextToken();
            } else {
                token = null;
            }

            int dialogID;
            synchronized (dialogs) {
                dialogID = dialogs.size();
                dialogs.add(dialog);
            }
            responses[i] = new AuthResponse(dialog.getStatus(), dialog.getDetailMessage(),
                                            dialogID, token);
        }
        return responses;
    }

    public AuthResponse[] auth(AuthRequest[] requests) throws RemoteException {
        AuthResponse[] responses = new AuthResponse[requests.length];
        for (int i=0; i<requests.length; i++) {
            AuthRequest request = requests[i];
            AuthDialog dialog = (AuthDialog)dialogs.get(request.dialogID);
            if (dialog == null) {
                throw new RemoteException("No authentication dialog with ID " +
                    request.dialogID + " (maybe it has already expired?)");
            }
            if (dialog.getStatus() != AuthResponse.IN_PROGRESS) {
                throw new RemoteException("Protocol error: dialog " + request.dialogID +
                                          " has already been over");
            }
            dialog.doPhase(request.token);
            byte[] nextToken = (dialog.getStatus() == AuthResponse.SUCCEEDED)
                ? dialog.getNextToken()
                : null;
            responses[i] = new AuthResponse(dialog.getStatus(), dialog.getDetailMessage(),
                                            request.dialogID, nextToken);
        }
        return responses;
    }

    public Set getAuthenticatedPrincipals() {
        Set principals = new HashSet();
        synchronized (dialogs) {
            for (Iterator i = dialogs.iterator(); i.hasNext(); ) {
                AuthDialog dialog = (AuthDialog)i.next();
                principals.addAll(dialog.getAuthenticatedPrincipals());
            }
        }
        return principals;
    }

    public Set getPublicCredentials() {
        Set credentials = new HashSet();
        synchronized (dialogs) {
            for (Iterator i = dialogs.iterator(); i.hasNext(); ) {
                AuthDialog dialog = (AuthDialog)i.next();
                credentials.addAll(dialog.getPublicCredentials());
            }
        }
        return credentials;
    }

    public Set getDelegatedCredentials() {
        Set credentials = new HashSet();
        synchronized (dialogs) {
            for (Iterator i = dialogs.iterator(); i.hasNext(); ) {
                AuthDialog dialog = (AuthDialog)i.next();
                credentials.addAll(dialog.getDelegatedCredentials());
            }
        }
        return credentials;
    }
}
