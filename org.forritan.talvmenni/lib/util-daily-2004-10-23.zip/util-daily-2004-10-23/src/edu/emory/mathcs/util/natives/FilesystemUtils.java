/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.natives;

import java.io.*;
import edu.emory.mathcs.util.io.*;
import java.security.*;

/**
 * Utility methods to operate on files.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */
public class FilesystemUtils {

    private static final String[] chmodCandidates = new String[] {
        "/bin/chmod", "/usr/bin/chmod", "/bin/chmod.exe", "/usr/bin/chmod.exe"
    };

    private FilesystemUtils() {}

    public static boolean setExecutable(final File file, final boolean executable) {
        checkWrite(file);
        return ((Boolean)AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                return Boolean.valueOf(setExecutablePrivileged(file, executable));
            }
        })).booleanValue();
    }

    private static boolean setExecutablePrivileged(File file, boolean executable) {
        File chmod = findFile(chmodCandidates);
        if (chmod == null) return false;
        String[] cmdarr = new String[] { chmod.getAbsolutePath(),
            "a" + (executable ? "+" : "-") + "x", file.getPath() };
        return cmdexec(cmdarr);
    }

    public static boolean setPrivate(final File file) {
        checkWrite(file);
        return ((Boolean)AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                return Boolean.valueOf(setPrivatePrivileged(file));
            }
        })).booleanValue();
    }

    private static boolean setPrivatePrivileged(File file) {
        File chmod = findFile(chmodCandidates);
        if (chmod == null) return false;
        String[] cmdarr = new String[] { chmod.getAbsolutePath(),
            "og=", file.getPath() };
        return cmdexec(cmdarr);
    }


    private static boolean cmdexec(String[] cmdarr) {
        try {
            Process p = Runtime.getRuntime().exec(cmdarr);
            p.waitFor();
            return p.exitValue() != 0;
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        catch (IOException e) {
            return false;
        }
    }

    public static File findFile(String[] candidates) {
        for (int i=0; i<candidates.length; i++) {
            File f = new File(candidates[i]);
            if (f.isFile()) return f;
        }
        return null;
    }


    private static void checkWrite(File file) {
        SecurityManager security = System.getSecurityManager();
        if (security != null) {
            security.checkWrite(file.getPath());
        }
    }

}