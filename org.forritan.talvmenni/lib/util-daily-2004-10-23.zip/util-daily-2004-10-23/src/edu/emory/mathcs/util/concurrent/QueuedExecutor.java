/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.concurrent;

/**
 *
 * An implementation of Executor that queues incoming
 * requests until they can be processed by a single background
 * thread.
 * <p>
 * The thread is not actually started until the first
 * <code>execute</code> request is encountered. Also, if the
 * thread is stopped for any reason (for example, after hitting
 * an unrecoverable exception in an executing task), one is started
 * upon encountering a new request, or if <code>restart()</code> is
 * invoked.
 * <p>
 * Beware that, especially in situations
 * where command objects themselves invoke execute, queuing can
 * sometimes lead to lockups, since commands that might allow
 * other threads to terminate do not run at all when they are in the queue.
 * <p>[<a href="http://gee.cs.oswego.edu/dl/classes/edu/oswego/cs/dl/util/concurrent/intro.html"> Introduction to this package. </a>]
 **/
public class QueuedExecutor extends ThreadFactoryUser implements Executor {



  /** The thread used to process commands **/
  protected Thread thread_;

  /** Special queue element to signal termination **/
  protected static Runnable ENDTASK = new Runnable() { public void run() {} };

  /** true if thread should shut down after processing current task **/
  protected volatile boolean shutdown_; // latches true;

  protected int finalCountdown = -1;

  /** how long to wait before stopping runner for empty queue */
  protected long timeout;

  /**
   * Return the thread being used to process commands, or
   * null if there is no such thread. You can use this
   * to invoke any special methods on the thread, for
   * example, to interrupt it.
   **/
  public synchronized Thread getThread() {
    return thread_;
  }

//  /** set thread_ to null to indicate termination **/
//  protected synchronized void clearThread() {
//    thread_ = null;
//  }
//

  /** The queue **/
  protected final BlockingQueue queue_;

  private Runnable getNextTask() throws InterruptedException {
    Runnable task;
    if (getPending() > 0) {
      task = (Runnable)queue_.take();
    }
    else {
      task = (Runnable) (queue_.poll(timeout, TimeUnit.MILLISECONDS));
      if (task == null) {
        // timeout
        return null;
      }
    }
    if (task == ENDTASK) {
        shutdown_ = true;
        task = null;
    }
    decreasePending();
    return task;
  }

  /**
   * The runloop is isolated in its own Runnable class
   * just so that the main
   * class need not implement Runnable,  which would
   * allow others to directly invoke run, which would
   * never make sense here.
   **/
  protected class RunLoop implements Runnable {
    public void run() {
      try {
        while (!shutdown_) {
          Runnable task = getNextTask();
          if (task == null) {
            // timeout or shutdown
            break;
          }
          else {
            task.run();
            task = null;
          }
        }
      }
      catch (InterruptedException ex) {} // fallthrough
      catch (Throwable t) {
          // unexpected error; exit and mark as shut down
          shutdown_ = true;
      }
      finally {
        stop();
      }
    }
  }

  protected final RunLoop runLoop_;


  /**
   * Construct a new QueuedExecutor that uses
   * the supplied Channel as its queue, and with specified timeout.
   * <p>
   * This class does not support any methods that
   * reveal this queue. If you need to access it
   * independently (for example to invoke any
   * special status monitoring operations), you
   * should record a reference to it separately.
   **/

  public QueuedExecutor(BlockingQueue queue, long timeout) {
    queue_ = queue;
    this.timeout = timeout;
    runLoop_ = new RunLoop();
  }

  /**
   * Construct a new QueuedExecutor that uses
   * the supplied Channel as its queue.
   * <p>
   * This class does not support any methods that
   * reveal this queue. If you need to access it
   * independently (for example to invoke any
   * special status monitoring operations), you
   * should record a reference to it separately.
   */
  public QueuedExecutor(BlockingQueue queue) {
    this(queue, Long.MAX_VALUE);
  }

  /**
   * Construct a new QueuedExecutor that uses
   * a BoundedLinkedQueue with the current
   * DefaultChannelCapacity as its queue, and with specified timeout
   */
  public QueuedExecutor(long timeout) {
    this(new BoundedLinkedQueue(), timeout);
  }

  /**
   * Construct a new QueuedExecutor that uses
   * a BoundedLinkedQueue with the current
   * DefaultChannelCapacity as its queue.
   */
  public QueuedExecutor() {
    this(new BoundedLinkedQueue());
  }

  private int pending;

  private synchronized void increasePending() {
      if (shutdown_) {
          throw new IllegalStateException("Executor is shut down");
      }
      if (finalCountdown >= 0) {
          throw new IllegalStateException("Executor is shutting down");
      }
      pending++;
      if (thread_ == null) {
          thread_ = threadFactory_.newThread(runLoop_);
          thread_.start();
      }
  }

  private synchronized int getPending() {
      return pending;
  }

  private synchronized void decreasePending() {
      pending--;
      if (finalCountdown > 0) {
          finalCountdown--;
          if (finalCountdown == 0) {
              shutdown_ = true;
          }
      }
  }

  /**
   * Called from within the run loop when the processing thread is about to
   * exit. This method may cause spawning a new processing thread to replace
   * the exiting one if there are pending execution requests.
   */
  private synchronized void stop() {
      if (pending <= 0) {
          thread_ = null;
      }
      else if (!shutdown_) {
          // tasks has been queued meanwhile; spawn a new processing thread
          thread_ = threadFactory_.newThread(runLoop_);
          thread_.start();
      }
  }

//  /**
//   * Start (or restart) the background thread to process commands. It has
//   * no effect if a thread is already running. This
//   * method can be invoked if the background thread crashed
//   * due to an unrecoverable exception.
//   **/
//
//  public synchronized void restart() {
//    if (thread_ == null && !shutdown_) {
//      thread_ = threadFactory_.newThread(runLoop_);
//      thread_.start();
//    }
//  }
//

  /**
   * Arrange for execution of the command in the
   * background thread by adding it to the queue.
   * The method may block if the channel's put
   * operation blocks.
   * <p>
   * If the background thread
   * does not exist, it is created and started.
   *
   * DK: made synchronized to avoid the following race condition: execute()
   * invokes restart() to make sure thread is alive, then runloop discovers
   * that queue is empty and destroys the thread, then execute calls queue.put()
   * with the command that will never be executed since thread is killed.
   * Note: it is not correct to reverse the order of queue.put() and restart(),
   * since queue may be implemented without buffer (blocking until put and get
   * meet).
   **/
  public void execute(Runnable command) {
//    if (shutdown_) {
//        throw new IllegalStateException();
//    }
    increasePending();
    try {
        queue_.put(command);
    }
    catch (InterruptedException e) {
        Thread.currentThread().interrupt();
    }
  }

  /**
   * Terminate background thread after it processes all
   * elements currently in queue. Any tasks entered after this point will
   * not be processed. A shut down thread cannot be restarted.
   * This method may block if the task queue is finite and full.
   * Also, this method
   * does not in general apply (and may lead to comparator-based
   * exceptions) if the task queue is a priority queue.
   **/
  public void shutdownAfterProcessingCurrentlyQueuedTasks() {
    synchronized (this) {
      if (shutdown_) return;
      if (pending == 0) {
        // no enqueued tasks
        if (thread_ == null) {
          // thread is not running
          shutdown_ = true;
          return;
        }
        else {
          // thread is currently waiting for a task; leave the synchronized
          // block and schedule ENDTASK to immediately wake it up
          pending = 1;
          finalCountdown = 1;
        }
      }
      else {
        finalCountdown = pending;
        // runner will set shutdown_ to true when finalCountdown reaches 0
        return;
      }
    }
    try {
      queue_.put(ENDTASK);
    }
    catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
  }


  /**
   * Terminate background thread after it processes the
   * current task, removing other queued tasks and leaving them unprocessed.
   * A shut down thread cannot be restarted.
   **/
  public void shutdownAfterProcessingCurrentTask() {
    synchronized (this) {
      shutdown_ = true;
      // no further tasks will be accepted
      if (pending == 0) {
        // no enqueued tasks
        if (thread_ == null) {
          // thread is not running
          return;
        }
        else {
          // thread is currently waiting for a task; leave the synchronized
          // block and schedule ENDTASK to immediately wake it up
          pending = 1;
          finalCountdown = 1;
        }
      }
      else {
        // thread is currently processing tasks; it will see the shutdown_
        // flag set and it will exit, ignoring unprocessed tasks
        return;
      }
    }
    try {
      queue_.put(ENDTASK);
    }
    catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
  }


  /**
   * Terminate background thread even if it is currently processing
   * a task. This method uses Thread.interrupt, so relies on tasks
   * themselves responding appropriately to interruption. If the
   * current tasks does not terminate on interruption, then the
   * thread will not terminate until processing current task.
   * A shut down thread cannot be restarted.
   **/
  public void shutdownNow() {
    synchronized (this) {
      shutdown_ = true;
      if (thread_ == null) return;
      thread_.interrupt();
    }
    shutdownAfterProcessingCurrentTask();
  }
}
