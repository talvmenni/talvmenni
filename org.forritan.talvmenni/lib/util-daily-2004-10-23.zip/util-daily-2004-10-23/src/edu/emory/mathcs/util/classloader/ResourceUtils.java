/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.classloader;

import java.util.regex.*;
import java.net.*;

/**
 * Utility methods related to remote resource access.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */
public class ResourceUtils {

    private static final Pattern dotInMiddlePattern    = Pattern.compile("/\\./");
    private static final Pattern dotAtBegPattern       = Pattern.compile("^\\./");
    private static final Pattern dotAtEndPattern       = Pattern.compile("/\\.$");
    private static final Pattern multipleSlashPattern  = Pattern.compile("/+");
    private static final Pattern initialParentPattern  = Pattern.compile("/?(\\.\\./)*");
    private static final Pattern embeddedParentPattern = Pattern.compile("[^/]+/\\.\\./");
    private static final Pattern trailingParentPattern = Pattern.compile("[^/]+/\\.\\.$");

    private ResourceUtils() {}

    /**
     * Checks if the URI points to the local file.
     * @param uri the uri to check
     * @return true if the URI points to a local file
     */
    public static boolean isLocalFile(URI uri) {
        if (!uri.isAbsolute()) return false;
        if (uri.isOpaque()) return false;
        if (!"file".equalsIgnoreCase(uri.getScheme())) return false;
        if (uri.getAuthority() != null) return false;
        if (uri.getFragment() != null) return false;
        if (uri.getQuery() != null) return false;
        if ("".equals(uri.getPath())) return false;
        return true;
    }

    /**
     * Returns the path converted to the canonic form. Examples:
     * <pre>
     *  "/aaa/b/"                                      ->  "/aaa/b/"
     *  "/aaa/b/c/../.."                               ->  "/aaa/"
     *  "/aaa/../bbb/cc/./.././../dd/eee/fff/."        ->  "/dd/eee/fff/"
     *  "../aaa/../././bbb/./../ccc/"                  ->  "../ccc/"
     *  "aa/ddfdd/./sadfd/.././sdafa/../../.././././"  ->  ""
     *  "./aaa/."                                      ->  "aaa/"
     *  ".///aa//bb/"                                  ->  "aa/bb/"
     *  "../../aaa"                                    ->  "../../aaa"
     *  "/../../aaa"                                   ->  "/../../aaa"
     * </pre>
     */
    public static String canonizePath(String path) {
        StringBuffer buf = new StringBuffer(path);
        StringBuffer aux = new StringBuffer();
        while (replaceAll(buf, aux, dotInMiddlePattern, "/", 0));
        replaceAll(buf, aux, multipleSlashPattern, "/", 0);
        replaceFirst(buf, aux, dotAtBegPattern, "", 0);
        replaceFirst(buf, aux, dotAtEndPattern, "/", 0);

        int pos = 0;
        while (pos < buf.length()) {
            pos += skipPrefix(buf, aux, initialParentPattern, pos);
            if (!replaceFirst(buf, aux, embeddedParentPattern, "", pos)) {
                break;
            }
        }

        replaceFirst(buf, aux, trailingParentPattern, "", pos);

        return buf.toString();
    }

    private static boolean replaceFirst(StringBuffer buf, StringBuffer aux,
                                        Pattern pattern, String replacement, int pos) {
        boolean chg = false;
        aux.setLength(0);
        Matcher matcher = pattern.matcher(buf);
        if (matcher.find(pos)) {
            matcher.appendReplacement(aux, replacement);
            chg = true;
        }
        matcher.appendTail(aux);
        buf.setLength(0);
        buf.append(aux);
        return chg;
    }

    private static boolean replaceAll(StringBuffer buf, StringBuffer aux,
                                      Pattern pattern, String replacement, int pos) {
        aux.setLength(0);
        Matcher matcher = pattern.matcher(buf);
        boolean found = matcher.find(pos);
        boolean chg = found;
        while (found) {
            matcher.appendReplacement(aux, replacement);
            found = matcher.find();
        }
        matcher.appendTail(aux);
        buf.setLength(0);
        buf.append(aux);
        return chg;
    }

    private static int skipPrefix(StringBuffer buf, StringBuffer aux,
                                  Pattern pattern, int pos) {
        Matcher matcher = initialParentPattern.matcher(buf);
        if (matcher.find(pos)) {
            return matcher.end()-pos;
        }
        return 0;
    }
}
