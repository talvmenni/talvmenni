package edu.emory.mathcs.util.security.auth;

import java.util.*;

public class Wallet {

    final Set credentials = new HashSet();
    boolean readOnly;

    public Wallet() {}

    public void setReadOnly() {
        readOnly = true;
    }

    public Set getCredentials() {
        return readOnly
            ? Collections.unmodifiableSet(credentials)
            : credentials;
    }

    public boolean addCredential(RemoteCredential cred) {
        if (readOnly) {
            throw new IllegalStateException("Wallet is read-only");
        }
        return credentials.add(cred);
    }

    public boolean removeCredential(RemoteCredential cred) {
        if (readOnly) {
            throw new IllegalStateException("Wallet is read-only");
        }
        return credentials.remove(cred);
    }
}
