
package edu.emory.mathcs.util.security.auth.server;

import java.rmi.*;

public interface AuthContextSrv extends Remote {
    AuthResponse[] initAuth(AuthInitRequest[] authRequests) throws RemoteException;
    AuthResponse[] auth(AuthRequest[] authRequests) throws RemoteException;
}
