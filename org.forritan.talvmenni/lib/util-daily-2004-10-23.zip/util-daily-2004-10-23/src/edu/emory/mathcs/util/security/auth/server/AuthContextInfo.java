package edu.emory.mathcs.util.security.auth.server;

import java.io.*;

/**
 * <p>Title: Util</p>
 * <p>Description: Emory MathCS Utility Classes</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Emory University</p>
 * @author Dawid Kurzyniec
 * @version 1.0
 */

public class AuthContextInfo implements Serializable {
    public AuthContextSrv server;
    public String[] supportedProtocols;
    public AuthContextInfo() {}
    public AuthContextInfo(AuthContextSrv server, String[] supportedProtocols) {
        this.server = server;
        this.supportedProtocols = supportedProtocols;
    }
}
