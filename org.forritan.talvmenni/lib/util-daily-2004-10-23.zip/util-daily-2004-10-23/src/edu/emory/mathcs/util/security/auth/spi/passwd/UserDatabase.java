package edu.emory.mathcs.util.security.auth.spi.passwd;

public interface UserDatabase {

    User getUser(String userID);

    public static interface User {
        String getID();
        String[] getGroups();
        boolean verifyPassword(char[] passwd);
    }
}
