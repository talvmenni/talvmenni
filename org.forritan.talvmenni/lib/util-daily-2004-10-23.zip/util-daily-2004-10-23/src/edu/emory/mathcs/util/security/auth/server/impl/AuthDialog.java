package edu.emory.mathcs.util.security.auth.server.impl;

import edu.emory.mathcs.util.security.auth.*;
import java.security.Principal;
import java.util.*;

public interface AuthDialog {
    int getStatus();
    String getDetailMessage();
    void doPhase(byte[] token);
    byte[] getNextToken();
    Set getAuthenticatedPrincipals();
    Set getPublicCredentials();
    Set getDelegatedCredentials();
}
