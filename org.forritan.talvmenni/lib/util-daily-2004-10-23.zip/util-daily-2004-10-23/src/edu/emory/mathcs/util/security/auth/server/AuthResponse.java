package edu.emory.mathcs.util.security.auth.server;

import java.io.*;

public class AuthResponse implements Serializable {

    public static final int SUCCEEDED   = 0x100;
    public static final int FAILED      = 0x200;
    public static final int IN_PROGRESS = 0x400;

    public int status;
    public String detailMessage;
    public int dialogID;
    public byte[] token;

    public AuthResponse() {}
    public AuthResponse(int status, String detailMessage, int dialogID, byte[] token) {
        this.status = status;
        this.detailMessage = detailMessage;
        this.dialogID = dialogID;
        this.token = token;
    }
}
