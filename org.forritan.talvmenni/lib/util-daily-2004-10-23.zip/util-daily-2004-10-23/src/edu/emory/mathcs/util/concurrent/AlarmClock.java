/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.concurrent;

import java.util.*;

/**
 * This class provide some value-added over java.util.Timer: that is,
 * it enables rescheduling of previously scheduled tasks.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */
public class AlarmClock {
    final Timer engine;
    final Runnable task;
    TimerTask timerTask;

    public AlarmClock(Timer engine, Runnable task) {
        this.engine = engine;
        this.task = task;
    }

    /**
     * Reschedule previously scheduled task unless it would postpone it.
     * In other words, if the requested delay is longer than the time remaining
     * until the previously scheduled execution, the request is ignored.
     *
     * @param delay the new delay before the task is to be executed,
     *              measured from the moment the method is invoked.
     * @returns true if successful, false otherwise (that is, if task is already
     *          running or complete)
     */
    public synchronized void setAlarmDelayIfSooner(long delay) {
        if (delay < 0) {
            // infinite; can't be more restrictive than anything
            return;
        }
        if (timerTask != null) {
            long oldDelay = timerTask.scheduledExecutionTime() - System.currentTimeMillis();
            if (delay >= oldDelay) {
                // not more restrictive; ignore request
                return;
            }
        }
        setAlarmDelay(delay);
    }

    /**
     * Reschedule previously scheduled task.
     *
     * @param delay the new delay before the task is to be executed,
     *              measured from the moment the method is invoked.
     * @returns true if successful, false otherwise (that is, if task is already
     *          running or complete)
     */
    public synchronized boolean setAlarmDelay(long delay) {
        if (timerTask != null) {
            if (!cancel()) {
                // task is running at the moment
                return false;
            }
        }
        // start timer
        timerTask = new TimerTask() {
            public void run() {
                task.run();
                synchronized (AlarmClock.this) {
                    // job done; suicide
                    AlarmClock.this.timerTask = null;
                }
            }
        };

        engine.schedule(timerTask, delay);
        return true;
    }

    /**
     * Cancel the scheduled task.
     *
     * @return true if successful, false otherwise.
     * @see TimerTask#cancel
     */
    public synchronized boolean cancel() {
        if (timerTask != null) {
            boolean result = timerTask.cancel();
            timerTask = null;
            return result;
        }
        return false;
    }
}