/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.security;

import java.security.*;
import java.security.spec.*;

/**
 * Utility methods to generate and manipulate keys.
 *
 * @see Key
 * @see KeyPair
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */

public class KeyUtils {

    private KeyUtils() {}

    /**
     * Generates an 1024-bit RSA key pair.
     * @return newly generated RSA key pair.
     */
    public static KeyPair generateRSAKeyPair() {
        return generateRSAKeyPair(1024);
    }

    /**
     * Generates RSA key pair of the specified size.
     *
     * @param keysize the RSA key size
     * @return newly generated RSA key pair.
     */
    public static KeyPair generateRSAKeyPair(int keysize) {
        try {
            KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
            gen.initialize(keysize);
            return gen.generateKeyPair();
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("FATAL: RSA not supported", e);
        }
    }

    /**
     * Decodes the RSA public key out of its X.509 encoding.
     *
     * @param encoded X.509 encoding of an RSA public key
     * @return the decoded public key
     */
    public static PublicKey decodeRSAPublicKey(byte[] encoded) {
        X509EncodedKeySpec spec = new X509EncodedKeySpec(encoded);
        try {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePublic(spec);
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("FATAL: RSA not supported", e);
        }
        catch (InvalidKeySpecException e) {
            throw new RuntimeException("FATAL: RSA does not support X509 encoding", e);
        }
    }

    /**
     * Generates an 1024-bit DSA key pair.
     * @return newly generated DSA key pair.
     */
    public static KeyPair generateDSAKeyPair() {
        return generateDSAKeyPair(1024);
    }

    /**
     * Generates DSA key pair of the specified size.
     *
     * @param keysize the DSA key size
     * @return newly generated DSA key pair.
     */
    public static KeyPair generateDSAKeyPair(int keysize) {
        try {
            KeyPairGenerator gen = KeyPairGenerator.getInstance("DSA");
            gen.initialize(keysize);
            return gen.generateKeyPair();
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("FATAL: DSA not supported", e);
        }
    }

    /**
     * Decodes the DSA public key out of its X.509 encoding.
     *
     * @param encoded X.509 encoding of an DSA public key
     * @return the decoded public key
     */
    public static PublicKey decodeDSAPublicKey(byte[] encoded) {
        X509EncodedKeySpec spec = new X509EncodedKeySpec(encoded);
        try {
            KeyFactory kf = KeyFactory.getInstance("DSA");
            return kf.generatePublic(spec);
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("FATAL: DSA not supported", e);
        }
        catch (InvalidKeySpecException e) {
            throw new RuntimeException("FATAL: DSA does not support X509 encoding", e);
        }
    }
}
