package edu.emory.mathcs.util.security.auth.spi.passwd;

import edu.emory.mathcs.util.security.auth.*;
import javax.security.auth.*;
import java.io.*;
import java.util.*;
import edu.emory.mathcs.util.security.io.*;
import edu.emory.mathcs.util.security.auth.server.impl.*;
import edu.emory.mathcs.util.security.*;

public class PasswdRemoteCredential implements RemoteCredential, Destroyable {

    static final String PROTOCOL = "rauth.h2o.passwd 1.0";
    static final String[] protocols = new String[] { PROTOCOL };

    private boolean delegate = false;

    static String[] staticGetSupportedProtocols() {
        return protocols;
    }

    boolean destroyed = false;

    private PasswdPublicCredential publicCred;
    private char[] passwd;

    public PasswdRemoteCredential(String userID, char[] passwd,
                                  boolean delegate)
    {
        this(new PasswdPublicCredential(userID), passwd, delegate);
    }

    public PasswdRemoteCredential(PasswdPublicCredential publicCred, char[] passwd,
                                  boolean delegate)
    {
        this.publicCred = publicCred;
        this.passwd = (char[])passwd.clone();
        this.delegate = delegate;
    }

    public String[] getSupportedProtocols() {
        return staticGetSupportedProtocols();
    }

    public Object getPublicCredential() {
        return publicCred;
    }

    public AuthDialogClient initiateAuth(String protocol) {
        checkProtocolAndState(protocol);
        return new PasswdAuthDialogClient();
    }

    private class PasswdAuthDialogClient implements AuthDialogClient {
        private boolean done = false;

        public byte[] getNextToken() {
            if (done) throw new IllegalStateException();
            ByteArrayOutputStream bos = new SecureByteArrayOutputStream(64);
            DataOutputStream dos = new DataOutputStream(bos);
            try {
                publicCred.writeTo(dos);
                CharStrings.writeUTF(dos, passwd);
                dos.writeBoolean(delegate);
                done = true;
                return bos.toByteArray();
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
            finally {
                bos.reset();
                try { dos.close(); } catch (IOException e) {}
            }
        }

        public void doPhase(byte[] token) {
            throw new UnsupportedOperationException("This is one-phase protocol");
        }
    }

    public void destroy() {
        Arrays.fill(passwd, (char)0);
        passwd = null;
        destroyed = true;
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    private void checkProtocolAndState(String protocol) {
        if (destroyed) {
            throw new IllegalStateException("Credential has been destroyed");
        }
        if (!(PROTOCOL.equalsIgnoreCase(protocol))) {
            throw new IllegalArgumentException("Unsupported protocol: " + protocol);
        }
    }

    public String toString() {
        return publicCred.toString();
    }
}
