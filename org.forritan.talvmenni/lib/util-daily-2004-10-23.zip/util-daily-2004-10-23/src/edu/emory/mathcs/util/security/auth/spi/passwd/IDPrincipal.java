/*
 * IDPrincipal.java
 *
 * Created on January 13, 2003, 6:36 PM
 */
package edu.emory.mathcs.util.security.auth.spi.passwd;

import java.security.*;


/**
 * DOCUMENT ME!
 *
 * @author Drzewo
 */
public abstract class IDPrincipal implements Principal {
}
