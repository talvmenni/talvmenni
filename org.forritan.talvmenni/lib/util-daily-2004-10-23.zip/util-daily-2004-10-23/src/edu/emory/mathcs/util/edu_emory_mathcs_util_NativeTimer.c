#include <jni.h>
#include <time.h>

JNIEXPORT jdouble JNICALL Java_edu_emory_mathcs_util_NativeTimer_getTimeOfDay
  (JNIEnv *env, jclass cls)
{
    struct timeval tp;
    struct timezone tzp;
    gettimeofday(&tp, &tzp);
    return tp.tv_sec*1000000.0 + tp.tv_usec;
}

