/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.io;

import java.io.*;
import java.util.zip.*;

/**
 * Filter input stream that is able to decompress data compressed with
 * {@link CompressedOutputStream}. Since the latter features strong
 * flush semantics, the two can be used as a transport for RMI or RPC.
 *
 * Note that standard {@link java.util.zip.ZipOutputStream} and
 * {@link java.util.zip.GZIPOutputStream} are useless for this purpose due to
 * their insufficiently strong flushing semantics: they don't guarantee that
 * flush sends out all the data that was written so far, which leads to
 * deadlocks in request-response-based protocols.
 *
 * @see CompressedOutputStream
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */
public class CompressedInputStream extends FilterInputStream {

    final static short DEFLATED = (short)0x8000;
    final static short STORED   = (short)0x0000;

    final byte[] buf;
    final DataInputStream din;
    final Inflater inflater;
    boolean deflated = false;
    int pending = 0;

    /**
     * Creates a new compressed stream over a specified stream.
     *
     * @param in the input to read from
     */
    public CompressedInputStream(InputStream in) {
        this(in, 8192);
    }

    /**
     * Creates a new compressed stream that reads from a specified stream and
     * uses specified buffer size.
     *
     * @param in the input to read from
     * @param bufSize buffer size
     */
    public CompressedInputStream(InputStream in, int bufSize) {
        super(in);
        buf = new byte[bufSize];
        this.inflater = new Inflater(true);
        this.din = new DataInputStream(in);
    }

    public synchronized int read() throws IOException {
        byte[] tmp = new byte[1];
        int read = read(tmp);
        if (read < 0) return -1;
        return tmp[0];
    }

    public synchronized int read(byte[] dest, int off, int len) throws IOException {
        // apparently (confirmed by experiments), finished() is not
        // reliable for GZIP streams (with noWrap option); we do want
        // to use GZIP though in (favor of ZIP) since it has less metadata
        // associated with the stream, thus more efficient overall compression
        while (true) {
            if (deflated) {
                // first try returning whatever is left in the inflater buf
                try {
                    int inflated = inflater.inflate(dest, off, len);
                    if (inflated > 0) {
                        return inflated;
                    }
                }
                catch (DataFormatException e) {
                    throw new IOException(e.toString());
                }

                if (pending == 0 || inflater.finished()) {
                    if (pending > 0) {
                        throw new IOException("Premature end of compressed data block");
                    }
                    if (!(newPacket())) return -1;
                    if (!deflated) continue;
                }
                if (inflater.needsInput()) {
                    int todo = Math.min(buf.length, pending);
                    int read = in.read(buf, 0, todo);
                    if (read < 0) {
                        throw new EOFException("Unexpected EOF");
                    }
                    pending -= read;
                    inflater.setInput(buf, 0, read);
                    continue;
                }
                else {
                    throw new RuntimeException();
                }
            }
            else {
                if (pending == 0) {
                    if (!(newPacket())) return -1;
                    if (deflated) continue;
                }
                int todo = Math.min(pending, len);
                int read = in.read(dest, off, todo);
                if (read < 0) {
                    throw new EOFException("Unexpected EOF");
                }
                pending -= read;
                return read;
            }
        }
    }

    private boolean newPacket() throws IOException {
        short header;
        try {
            header = din.readShort();
        }
        catch (EOFException e) {
            return false;
        }
        deflated = ((header & DEFLATED) == DEFLATED);
        pending = header & 0x7FFF;
        if (pending <= 0) {
            throw new IOException("Bogus packet length");
        }
        if (deflated) {
            inflater.reset();
        }
        return true;
    }
}
