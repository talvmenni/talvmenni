/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the Emory Utilities.
 *
 * The Initial Developer of the Original Code is
 * The Distributed Computing Laboratory, Emory University.
 * Portions created by the Initial Developer are Copyright (C) 2002
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package edu.emory.mathcs.util.concurrent;

import java.security.*;

/**
 * Thread factory implementation that attempts to ensure that created threads
 * are equivalent regardless of threads that request creation. Precisely,
 * created threads belong to the same thread group, and they inherit a
 * "parent thread context" (access control context,
 * {@link DelegatableThreadLocal}s, etc.) from the factory creator rather than
 * from the invoker of {@link #newThread}.
 * <p>
 * This thread factory is used as a default for {@link PooledExecutor}, as it
 * guarantees deterministic behavior and minimal security properties.
 * Nevertheless, stronger semantics are often neccessary in
 * security-sensitive applications. In particular,
 * it may be required that worker tasks run within access control context and
 * with delegatable locals of the thread that scheduled the task, which
 * may generally be distinct from both the thread pool creator and the worker
 * thread creator. If such security semantics is needed, use
 * {@link SecurePooledExecutor}.
 *
 * @author Dawid Kurzyniec
 * @version 1.0
 */

public class PlainThreadFactory implements ThreadFactory {
    final AccessControlContext acc;
    final ThreadGroup group;
    final ThreadContext tc;
    final String name;
    int idx = 0;

    /**
     * Creates a new tread factory that creates threads within a default
     * thread group. The group of the current thread (invoking this
     * constructor) is used as a default unless explicitly overridden
     * by current security manager.
     */
    public PlainThreadFactory() {
        this(null, null);
    }

    /**
     * Creates a new tread factory that uses default thread group and
     * specified thread name prefix. The group of the current thread (invoking
     * this constructor) is used as a default unless explicitly overridden
     * by current security manager.
     *
     * @param name the thread name prefix
     */
    public PlainThreadFactory(String name) {
        this(null, name);
    }

    /**
     * Creates a new tread factory that creates threads within the specified
     * thread group.
     *
     * @param group the thread group for created threads
     */
    public PlainThreadFactory(ThreadGroup group) {
        this(group, null);
    }

    /**
     * Creates a new tread factory that creates threads within the specified
     * thread group, and uses specified thread name prefix.
     *
     * @param group the thread group for created threads
     * @param name the thread name prefix
     */
    public PlainThreadFactory(ThreadGroup group, String name) {
        if (group == null) {
            // try to determine tg as in java.lang.Thread
            SecurityManager security = System.getSecurityManager();

            if (security != null) {
                group = security.getThreadGroup();
            }
        }

        if (group == null) {
            group = Thread.currentThread().getThreadGroup();
        }

        this.group = group;
        this.name = name;
        this.acc = AccessController.getContext();
        this.tc = ThreadContext.getContext();
    }

    public Thread newThread(final Runnable command) {
        return (Thread)AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
                Runnable commandWrapper = new DelegatedRunnable(command);
                if (name == null) {
                    return new Thread(group, commandWrapper);
                }
                else {
                    String tname = (name != null ? name + " " + getNextIdx() : null);
                    return new Thread(group, commandWrapper, tname);
                }
            }
        }, acc);
    }

    private synchronized int getNextIdx() {
        return idx++;
    }
}
