package edu.emory.mathcs.util.security.auth.server;

public class AuthRequest implements java.io.Serializable {
    public int dialogID;
    public byte[] token;
    public AuthRequest() {}
    public AuthRequest(int dialogID, byte[] token) {
        this.dialogID = dialogID;
        this.token = token;
    }
}
